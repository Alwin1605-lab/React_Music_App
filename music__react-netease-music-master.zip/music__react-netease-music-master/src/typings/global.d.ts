interface Type_Dictionary<T> {
  [key: string]: T;
}

declare let __LOCALHOST__: string;
