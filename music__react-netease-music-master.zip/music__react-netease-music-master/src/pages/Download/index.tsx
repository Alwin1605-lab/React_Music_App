import React from 'react';

const Download = () => {
  return <div>Download</div>;
};

export default Download;
