import React from 'react';

const Cloud = () => {
  return <div>Cloud</div>;
};

export default Cloud;
