import React from 'react';

const Collection = () => {
  return <div>Collection</div>;
};

export default Collection;
