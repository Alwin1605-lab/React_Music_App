import { Type_Album } from './business';

export interface Type_GetAlbumResponse {
  album: Type_Album;
  songs: any[];
}
