export interface Type_Action {
  type: string;
  payload?: Type_Dictionary<any>;
}
